Overview
========
This project enables users to capture and save camera data
captured with the i.MXRT1060-EVK onto a micro-SD card. 

This project does not do inferencing of a model. Instead it is meant
to be used to generate images that can then be used on a PC for training a model. 
The images are saved in RGB NHWC format as a binary file on the microSD card,
 and then a Python script running on the PC can convert those binary files into PNG image format.


Toolchains supported
====================
- MCUXpresso IDE 11.2.0
- MCUXpresso SDK for RT1060

Hardware requirements
=====================
- Micro USB cable
- EVK-IMXRT1060 board with camera + RK043FN02H-CT LCD
- Micro SD card
- Personal computer (Windows)
- Micro SD card reader
- Python 3.x installed

Board settings
==============
Camera and LCD connected to i.MXRT1060-EVK 
https://community.nxp.com/t5/i-MX-RT-Knowledge-Base/Connecting-camera-and-LCD-to-i-MX-RT-EVKs/tac-p/1122184 

Prepare the demo
================
1. Insert a micro SD card into the micro SD card slot on the i.MXRT1060-EVK (J39)

2. Open MCUXpresso IDE 11.2 and import the project using "Import project(s) from file system.." from the 
   Quickstart panel. Use the "Archive" option to select the zip file that contains this project. 

3. If desired, two #define values can be modified in camera_capture.c to adjust the captured image size:
    #define EXTRACT_HEIGHT  256       //Max EXTRACT_HEIGHT value possible is 271 (due to border drawing)
    #define EXTRACT_WIDTH   256       //Max EXTRACT_WIDTH value possible is 480

4. Build the project by clicking on "Build" in the Quickstart Panel

5. Connect a USB cable between the host PC and the OpenSDA port (J41) on the target board.

6. Open a serial terminal with the following settings:
   - 115200 baud rate
   - 8 data bits
   - No parity
   - One stop bit
   - No flow control

7. Download the program to the target board by clicking on "Debug" in the Quickstart Panel

8. Click on the "Resume" icon to begin running the demo. 

Running the demo
================
The terminal will ask for a classification name. This will create a new directory on the SD card with
that name. The name size is limited to 5 characters because the FATFS file system supports only 8 
characters in a file name, and three of those characters are used to number the images. 

For best results, the selection rectangle should be centered on the image and nearly (but not completely) 
fill up the whole rectangle. The camera should be stabilized with your finger or by some other means to prevent shaking. 
Also ensure the camera lens has been focused as described in the instructions when connecting the camera and LCD 
(https://community.nxp.com/t5/i-MX-RT-Knowledge-Base/Connecting-camera-and-LCD-to-i-MX-RT-EVKs/tac-p/1122184). 


While running the demo, press the 'c' key to enter a new classification name, or press 'q' to quit the program and remove the 
micro SD card. 

Transfer the .bin files created on the SD card to your PC, and run the Python script found in the "scripts" directory to 
convert the images to PNG format. 

If the captured image is a square (width==height) the script can be called with:
python convert_image.py directory_name
which will convert all the .BIN files in the specified directory name.

If the captured image is not a square, the width and height can be specified at the command line:
python convert_image.py directory_name width height


Terminal Output
==============
Camera SD Card Capture
Extracted Image: Height x Width: 256x256

Please insert a card into board.

Card inserted.
Mounting SD Card

Enter name of new class (must be less than 5 characters):
test

Creating directory test......

Press any key to capture image. Press 'c' to change class or 'q' to quit

Writing file /test/test001.bin......
Write Complete
Press any key to capture image. Press 'c' to change class or 'q' to quit

Remove SD Card
