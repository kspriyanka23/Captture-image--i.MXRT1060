/*
 * Copyright 2019-2020 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>
#include "display_support.h"
#include "camera_support.h"
#include "fsl_pxp.h"


#include "board.h"
#include "fsl_debug_console.h"
#include "pin_mux.h"

#include "timer.h"
#include "image.h"


#include "fsl_sd.h"
#include "ff.h"
#include "diskio.h"
#include "fsl_sd_disk.h"
#include "sdmmc_config.h"

// ---------------------------- Application -----------------------------

#define EXTRACT_HEIGHT  256       //Max EXTRACT_HEIGHT value possible is 271 (due to border drawing)
#define EXTRACT_WIDTH   256       //Max EXTRACT_WIDTH value possible is 480
#define IMAGE_CHANNELS  3

// buffer size (in byte) for read/write operations
#define BUFFER_SIZE (EXTRACT_HEIGHT * EXTRACT_WIDTH * IMAGE_CHANNELS)

//Cooridinates to start selection rectangle
int Rec_x = (480-EXTRACT_WIDTH)/2;
int Rec_y = (272-EXTRACT_HEIGHT)/2;

//Maximum file name character size is 8, and three characters are used for numbering, leaving 5 chars left for class name.
#define FILENAME_CHAR_LIMIT   5

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
/*!
 * @brief wait card insert function.
 */
static status_t sdcardWaitCardInsert(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/
static FATFS g_fileSystem; /* File system object */
static FIL g_fileObject;   /* File object */

/* @brief decription about the read/write buffer
 * The size of the read/write buffer should be a multiple of 512, since SDHC/SDXC card uses 512-byte fixed
 * block length and this driver example is enabled with a SDHC/SDXC card.If you are using a SDSC card, you
 * can define the block length by yourself if the card supports partial access.
 * The address of the read/write buffer should align to the specific DMA data buffer address align value if
 * DMA transfer is used, otherwise the buffer address is not important.
 * At the same time buffer address/size should be aligned to the cache line size if cache is supported.
 */
/*! @brief Data written to the card */
SDK_ALIGN(uint8_t g_bufferWrite[BUFFER_SIZE], BOARD_SDMMC_DATA_BUFFER_ALIGN_SIZE);
/*! @brief Data read from the card */
SDK_ALIGN(uint8_t g_bufferRead[BUFFER_SIZE], BOARD_SDMMC_DATA_BUFFER_ALIGN_SIZE);

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define APP_FRAME_BUFFER_COUNT 4
/* Pixel format RGB565, bytesPerPixel is 2. */
#define APP_BPP 2

#if (FRAME_BUFFER_ALIGN > DEMO_CAMERA_BUFFER_ALIGN)
#define DEMO_FRAME_BUFFER_ALIGN FRAME_BUFFER_ALIGN
#else
#define CAMERA_FRAME_BUFFER_ALIGN DEMO_CAMERA_BUFFER_ALIGN
#endif

/* PXP */
#define ROTATE_DISPLAY kPXP_Rotate180
#define APP_PXP PXP

#define APP_LCD_BUFFER_COUNT 2

#define APP_IMG_WIDTH DEMO_PANEL_WIDTH
#define APP_IMG_HEIGHT DEMO_PANEL_HEIGHT

/* PS input buffer is square. */
#if APP_IMG_WIDTH > APP_IMG_HEIGHT
#define APP_PS_SIZE APP_IMG_WIDTH
#else
#define APP_PS_SIZE APP_IMG_HEIGHT
#endif

#define APP_PS_ULC_X 0U
#define APP_PS_ULC_Y 0U
#define APP_PS_LRC_X (APP_IMG_WIDTH -1U)
#define APP_PS_LRC_Y (APP_IMG_HEIGHT- 1U)

#define APP_RED 0xF100U
#define APP_GREEN 0x07E0U
#define APP_BLUE 0x001FU
#define APP_WHITE 0xFFFFU
#define APP_PXP_PS_FORMAT kPXP_PsPixelFormatRGB565
#define APP_PXP_AS_FORMAT kPXP_AsPixelFormatRGB565
#define APP_PXP_OUT_FORMAT kPXP_OutputPixelFormatRGB565
#define APP_DC_FORMAT kVIDEO_PixelFormatRGB565

/* Tresholds */
#define DETECTION_TRESHOLD 60

#define INPUT_MEAN_SHIFT {125,123,114}
#define INPUT_RIGHT_SHIFT {8,8,8}

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void APP_BufferSwitchOffCallback(void *param, void *switchOffBuffer);
static void APP_CSIFullBufferReady(camera_receiver_handle_t *handle,
                                  status_t status, void *userData);
static void APP_Rotate(uint32_t input_buffer, uint32_t output_buffer);
static void APP_InitPxp(void);
static void APP_InitCamera(void);
static void APP_InitDisplay(void);
static void APP_CsiRgb565Start(void);
static void APP_CsiRgb565Refresh(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/
#if !defined(__ARMCC_VERSION)
AT_NONCACHEABLE_SECTION_ALIGN(
    static uint16_t s_frameBuffer[APP_FRAME_BUFFER_COUNT][DEMO_PANEL_HEIGHT][DEMO_PANEL_WIDTH],
    CAMERA_FRAME_BUFFER_ALIGN);

AT_NONCACHEABLE_SECTION_ALIGN(
    static uint16_t s_lcdBuf[APP_LCD_BUFFER_COUNT][DEMO_PANEL_HEIGHT][DEMO_PANEL_WIDTH],
    CAMERA_FRAME_BUFFER_ALIGN);

#else
AT_NONCACHEABLE_SECTION_ALIGN_INIT(
    static uint16_t s_frameBuffer[APP_FRAME_BUFFER_COUNT][DEMO_PANEL_HEIGHT][DEMO_PANEL_WIDTH],
    CAMERA_FRAME_BUFFER_ALIGN);

AT_NONCACHEABLE_SECTION_ALIGN_INIT(
    static uint16_t s_lcdBuf[APP_LCD_BUFFER_COUNT][DEMO_PANEL_HEIGHT][DEMO_PANEL_WIDTH],
    CAMERA_FRAME_BUFFER_ALIGN);
#endif

/*
 * When new frame buffer sent to display, it might not be shown immediately.
 * Application could use callback to get new frame shown notification, at the
 * same time, when this flag is set, application could write to the older
 * frame buffer.
 */
static volatile bool s_newFrameShown = false;
static dc_fb_info_t fbInfo;


static volatile bool g_getCameraData = false;
static volatile bool g_isCamDataExtracted = false;
//static uint16_t *pExtract = NULL;
uint16_t pExtract[EXTRACT_WIDTH * EXTRACT_HEIGHT];

static uint32_t cameraReceivedFrameAddr;
static uint8_t curLcdBufferIdx = 0;

uint32_t max_idx = 0;

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Rotate image PXP.
 * param input_buffer pointer to source image buffer.
 * param output_buffer pointer to output buffer for storing result.
 */
static void APP_Rotate(uint32_t input_buffer, uint32_t output_buffer)
{
  APP_PXP->PS_BUF = input_buffer;
  APP_PXP->OUT_BUF = output_buffer;
  /* Prepare next buffer for LCD. */
  PXP_SetRotateConfig(APP_PXP, kPXP_RotateOutputBuffer, ROTATE_DISPLAY, kPXP_FlipDisable);

  PXP_Start(APP_PXP);

  /* Wait for process complete. */
  while (!(kPXP_CompleteFlag & PXP_GetStatusFlags(APP_PXP)))
  {
  }

  PXP_ClearStatusFlags(APP_PXP, kPXP_CompleteFlag);
}

/*!
 * @brief Initializes PXP.
 */
static void APP_InitPxp(void)
{
  PXP_Init(APP_PXP);

  /* PS configure. */
  const pxp_ps_buffer_config_t psBufferConfig = {
    .pixelFormat = APP_PXP_PS_FORMAT,
    .swapByte    = false,
    .bufferAddr  = 0U,
    .bufferAddrU = 0U,
    .bufferAddrV = 0U,
    .pitchBytes  = APP_PS_SIZE * APP_BPP,
  };

  PXP_SetProcessSurfaceBackGroundColor(APP_PXP, 0U);

  PXP_SetProcessSurfaceBufferConfig(APP_PXP, &psBufferConfig);
  PXP_SetProcessSurfacePosition(APP_PXP, APP_PS_ULC_X, APP_PS_ULC_Y, APP_PS_LRC_X, APP_PS_LRC_Y);

  /* Disable AS. */
  PXP_SetAlphaSurfacePosition(APP_PXP, 0xFFFFU, 0xFFFFU, 0U, 0U);

  pxp_output_buffer_config_t outputBufferConfig;
  /* Output config. */
  outputBufferConfig.pixelFormat    = APP_PXP_OUT_FORMAT;
  outputBufferConfig.interlacedMode = kPXP_OutputProgressive;
  outputBufferConfig.buffer0Addr    = 0U;
  outputBufferConfig.buffer1Addr    = 0U;
  outputBufferConfig.pitchBytes     = APP_IMG_WIDTH * APP_BPP;
  outputBufferConfig.width          = APP_IMG_WIDTH;
  outputBufferConfig.height         = APP_IMG_HEIGHT;

  PXP_SetOutputBufferConfig(APP_PXP, &outputBufferConfig);

  /* Disable CSC1, it is enabled by default. */
  PXP_EnableCsc1(APP_PXP, false);
}

/*!
 * @brief Initializes camera.
 */
static void APP_InitCamera(void)
{
  const camera_config_t cameraConfig = {
    .pixelFormat   = kVIDEO_PixelFormatRGB565,
    .bytesPerPixel = APP_BPP,
    .resolution    = FSL_VIDEO_RESOLUTION(DEMO_CAMERA_WIDTH, DEMO_CAMERA_HEIGHT),
    /* Set the camera buffer stride according to panel, so that if
     * camera resoution is smaller than display, it can still be shown
     * correct in the screen.
     */
    .frameBufferLinePitch_Bytes = DEMO_PANEL_WIDTH * APP_BPP,
    .interface                  = kCAMERA_InterfaceGatedClock,
    .controlFlags               = DEMO_CAMERA_CONTROL_FLAGS,
    .framePerSec                = 30,
  };
  
  memset(s_frameBuffer, 0, sizeof(s_frameBuffer));

  BOARD_InitCameraResource();

  CAMERA_RECEIVER_Init(&cameraReceiver, &cameraConfig, APP_CSIFullBufferReady, NULL);

  if (kStatus_Success != CAMERA_DEVICE_Init(&cameraDevice, &cameraConfig))
  {
    PRINTF("Camera device initialization failed\r\n");
    while (1) {}
  }

  CAMERA_DEVICE_Start(&cameraDevice);

  /* Submit the empty frame buffers to buffer queue. */
  for (uint32_t i = 0; i < APP_FRAME_BUFFER_COUNT; i++)
  {
     CAMERA_RECEIVER_SubmitEmptyBuffer(&cameraReceiver, (uint32_t)(s_frameBuffer[i]));
  }
}

/*!
 * @brief Initializes LCD.
 */
static void APP_InitDisplay(void)
{
  status_t status;

  BOARD_PrepareDisplayController();

  status = g_dc.ops->init(&g_dc);
  if (kStatus_Success != status)
  {
    PRINTF("Display initialization failed\r\n");
    assert(0);
  }

  g_dc.ops->getLayerDefaultConfig(&g_dc, 0, &fbInfo);
  fbInfo.pixelFormat = kVIDEO_PixelFormatRGB565;
  fbInfo.width       = DEMO_PANEL_WIDTH;
  fbInfo.height      = DEMO_PANEL_HEIGHT;
  fbInfo.strideBytes = DEMO_PANEL_WIDTH * APP_BPP;
  g_dc.ops->setLayerConfig(&g_dc, 0, &fbInfo);

  g_dc.ops->setCallback(&g_dc, 0, APP_BufferSwitchOffCallback, NULL);
}

/*!
 * @brief Start CSI processing.
 */
static void APP_CsiRgb565Start(void)
{
  CAMERA_RECEIVER_Start(&cameraReceiver);

  /* Wait to get the full frame buffer to show. */
  while (kStatus_Success !=
    CAMERA_RECEIVER_GetFullBuffer(&cameraReceiver, &cameraReceivedFrameAddr)) {}

  APP_Rotate(cameraReceivedFrameAddr, (uint32_t)s_lcdBuf[curLcdBufferIdx]);

  s_newFrameShown = false;
  g_dc.ops->setFrameBuffer(&g_dc, 0, (void *)s_lcdBuf[curLcdBufferIdx]);

  /* For the DBI interface display, application must wait for the first
     frame buffer sent to the panel. */
  if ((g_dc.ops->getProperty(&g_dc) & kDC_FB_ReserveFrameBuffer) == 0)
  {
    while (s_newFrameShown == false) {}
  }

  s_newFrameShown = true;

  g_dc.ops->enableLayer(&g_dc, 0);
}

/*!
 * @brief Process camera buffer and send it to LCD.
  */
static void APP_CsiRgb565Refresh()
{
  /* Wait to get the full frame buffer to show. */
  while (kStatus_Success !=
    CAMERA_RECEIVER_GetFullBuffer(&cameraReceiver, &cameraReceivedFrameAddr)) {}

  curLcdBufferIdx ^= 1U;
  APP_Rotate(cameraReceivedFrameAddr, (uint32_t)s_lcdBuf[curLcdBufferIdx]);

  /* Check if camera buffer is extracted for new inference. */
  if (g_getCameraData)
  {
    /* Extract image from camera. */
    ExtractImage(pExtract, Rec_x, Rec_y, EXTRACT_WIDTH, EXTRACT_HEIGHT, (uint16_t *)cameraReceivedFrameAddr);

    /* Draw red rectangle. */
    DrawRect((uint16_t*)s_lcdBuf[curLcdBufferIdx],Rec_x, Rec_y, EXTRACT_WIDTH, EXTRACT_HEIGHT, 255, 0, 0);
    g_isCamDataExtracted= true;
  }
  else
  {
    /* Draw white rectangle. */
    DrawRect((uint16_t*)s_lcdBuf[curLcdBufferIdx], Rec_x, Rec_y, EXTRACT_WIDTH, EXTRACT_HEIGHT, 255, 255, 255);
  }

  s_newFrameShown = false;
  g_dc.ops->setFrameBuffer(&g_dc, 0, (void *)s_lcdBuf[curLcdBufferIdx]);
}

/*!
 * @brief Set new empty buffer for CSI.
 */
static void APP_BufferSwitchOffCallback(void *param, void *switchOffBuffer)
{
  s_newFrameShown = true;
  CAMERA_RECEIVER_SubmitEmptyBuffer(&cameraReceiver, (uint32_t)cameraReceivedFrameAddr);
}

static void APP_CSIFullBufferReady(camera_receiver_handle_t *handle,
                                   status_t status, void *userData)
{
  if (s_newFrameShown)
  {
    APP_CsiRgb565Refresh();
  }
}



static status_t sdcardWaitCardInsert(void)
{
    BOARD_SD_Config(&g_sd, NULL, BOARD_SDMMC_SD_HOST_IRQ_PRIORITY, NULL);

    /* SD host init function */
    if (SD_HostInit(&g_sd) != kStatus_Success)
    {
        PRINTF("\r\nSD host init fail\r\n");
        return kStatus_Fail;
    }
    /* power off card */
    SD_SetCardPower(&g_sd, false);

    /* wait card insert */
    if (SD_PollingCardInsert(&g_sd, kSD_Inserted) == kStatus_Success)
    {
        PRINTF("\r\nCard inserted.\r\n");
        /* power on the card */
        SD_SetCardPower(&g_sd, true);
    }
    else
    {
        PRINTF("\r\nCard detect fail.\r\n");
        return kStatus_Fail;
    }

    return kStatus_Success;
}

/* Get new class name and create directory on SD card */
int create_new_class(char* class_name)
{
  FRESULT error;
  uint8_t ch;
  char directory_name[20];


  PRINTF("\r\nEnter name of new class (must be less than 5 characters): \r\n");

  // Get new name one character at a time until reach filename limit or see Enter key
  bool end=false;
  int i=0;
  while(!end)
  {
    ch = GETCHAR();

    //If see Enter key, end string with NULL terminator
    if(ch=='\r' || ch=='\n')
    {
      end=true;
      class_name[i]='\0';  //End terminator
    }
    else
    {
      class_name[i]=ch;
      PUTCHAR(ch);        //Print out character just entered
      i++;

      //SDFAT only supports up to 8 characters for file name. 3 are used for numbering, leaving 5 for user input
      if(i==FILENAME_CHAR_LIMIT)
      {
        end=true;
        class_name[i]='\0';  //End terminator
      }
    }
  }

  PRINTF("\r\n");

  //Create new directory with the name just entered
  sprintf(directory_name, "/%s", class_name);
  PRINTF("\r\nCreating directory %s......\r\n\r\n",class_name);
  error = f_mkdir(_T(directory_name));
  if (error)
  {
	//If directory already exists, let user know. Program will continue unaffected.
    if (error == FR_EXIST)
    {
      PRINTF("Directory exists.\r\n");
    }
    else
    {
      PRINTF("Make directory failed.\r\n");
      return -1;
    }
  }

  return 1;
}

/* Extract camera data and save to SD card */
int save_image(char* class_name, uint8_t image_number)
{
    UINT bytesWritten;
    FRESULT error;
    char file_name[20];
    uint8_t data[EXTRACT_WIDTH * EXTRACT_HEIGHT * IMAGE_CHANNELS];

	//Transform the camera data to 24-bit RGB NHWC format
	CSI2Image(data, EXTRACT_WIDTH, EXTRACT_HEIGHT, pExtract, RGB_COLOR_ORDER, NHWC_DIMENSION_FORMAT);

	//Generate filename
    sprintf(file_name, "/%s/%s%03d.bin", class_name,class_name,image_number);
    PRINTF("\r\nWriting file %s......\r\n",file_name);


    //Open file for writing
    error = f_open(&g_fileObject, _T(file_name), (FA_WRITE | FA_READ | FA_CREATE_ALWAYS));
    if (error)
    {
      if (error == FR_EXIST)
      {
        PRINTF("File exists.\r\n");
      }
      else
      {
        PRINTF("Open file failed. Error code %d\r\n",error);
        return -1;
      }
    }

    //Write data to file
     error = f_write(&g_fileObject, data, EXTRACT_WIDTH * EXTRACT_HEIGHT * IMAGE_CHANNELS, &bytesWritten);
    if ((error) || (bytesWritten != EXTRACT_WIDTH * EXTRACT_HEIGHT * IMAGE_CHANNELS))
    {
        PRINTF("Write file failed because %d. Btyes written was %d\r\n",error,bytesWritten);
        return -1;
    }

    //Close file
    if (f_close(&g_fileObject))
    {
        PRINTF("\r\nClose file failed.\r\n");
        return -1;
    }
    PRINTF("Write Complete\r\n");

    return 1;
}

/*!
 * @brief Main function
 */
int main(void)
{
  FRESULT error;
  const TCHAR driverNumberBuffer[3U] = {SDDISK + '0', ':', '/'};
  uint8_t image_number=0;
  char key_pressed;

  char class_name[10];
  bool quit=false;
  bool change_class=false;

  /* Init board hardware. */
  BOARD_ConfigMPU();
  BOARD_InitPins();
  BOARD_InitDEBUG_UARTPins();
  BOARD_InitSDRAMPins();
  BOARD_EarlyPrepareCamera();
  BOARD_InitCSIPins();
  BOARD_InitLCDPins();
  BOARD_BootClockRUN();
  BOARD_InitDebugConsole();

  NVIC_SetPriorityGrouping(3);
  InitTimer();

  PRINTF("Camera SD Card Capture\r\n");
  PRINTF("Extracted Image: Height x Width: %dx%d\r\n",EXTRACT_HEIGHT,EXTRACT_WIDTH);

  APP_InitCamera();
  APP_InitDisplay();
  APP_InitPxp();

  /* Start CSI transfer */
  APP_CsiRgb565Start();

  /* Initialize SD Card */
  PRINTF("\r\nPlease insert a card into board.\r\n");
  if (sdcardWaitCardInsert() != kStatus_Success)
  {
	PRINTF("SD Card Insertion failed\r\n");
    return -1;
  }

  PRINTF("Mounting SD Card\r\n");
  if (f_mount(&g_fileSystem, driverNumberBuffer, 0U))
  {
    PRINTF("Mount volume failed.\r\n");
    return -1;
  }

  error = f_chdrive((char const *)&driverNumberBuffer[0U]);
  if (error)
  {
    PRINTF("Change drive failed.\r\n");
    return -1;
  }



  /* Main Program */
  while(!quit)
  {
    image_number=0;
    change_class=false;
    key_pressed=0;

    //Get user input for new class name and create new directory
    create_new_class(class_name);

    while (!change_class && !quit)
    {
      PRINTF("Press any key to capture image. Press 'c' to change class or 'q' to quit\r\n");
      //Wait for key press
      while(1)
      {
        DbgConsole_TryGetchar(&key_pressed);
        if(key_pressed)
        {
          if(key_pressed=='c')
          {
        	change_class=true;
          }
          if(key_pressed=='q')
          {
            quit=true;
          }

          key_pressed=0;

          //Wait for latest camera data
          g_getCameraData=true;
          while(g_isCamDataExtracted!=true)
	  	  {}
          g_getCameraData=false;

          break;
        }
      }

      //Write camera data to SD card
      if(!change_class && !quit)
      {
        image_number++;
        save_image(class_name,image_number);
      }
      g_isCamDataExtracted=false;
    }
  }


  PRINTF("\r\nRemove SD Card\r\n");
  while(1)
  {}
}
