from PIL import Image
import glob, os
import sys
import math

#Get folder name to convert from the first argument to script
class_name=sys.argv[1]
print("Class name: ",class_name)


#Get directory path
current_directory = os.getcwd()
directory=os.path.join(current_directory,class_name)
print("Directory name: ",directory)
os.chdir(directory)

#For all .BIN files in that directory, convert to png
for filename in glob.glob("*.BIN"):
  print("Processing ",filename)
   
  #Get number ID from the file name 
  num=filename[-7:-4]         

  #If dimensions aren't given, assume image is square and can get dimensions of image from its file size assuming it's an RGB file  
  if len(sys.argv) < 3:
    size = os.path.getsize(filename)
    width=int(math.sqrt(size/3))
    height=int(math.sqrt(size/3))
  else:
    width=int(sys.argv[2])
    height=int(sys.argv[3])
  
  #Read data
  with open(filename,'rb') as file: 
    data = file.read() 
	
  #Create new Image object and save as .png file
  im = Image.frombuffer('RGB', (width, height), data, 'raw', 'RGB', 0, 1)
  im.save(class_name+'_'+num+".png")
